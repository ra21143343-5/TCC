package PastaDTO;

public class CadastroPgrDTO {
	
	private String cadastro_pgrempresa;
	private String cadastro_pgrdatainicial;
	private String cadastro_pgrdatafinal;
	public String getCadastro_pgrempresa() {
		return cadastro_pgrempresa;
	}
	public void setCadastro_pgrempresa(String cadastro_pgrempresa) {
		this.cadastro_pgrempresa = cadastro_pgrempresa;
	}
	public String getCadastro_pgrdatainicial() {
		return cadastro_pgrdatainicial;
	}
	public void setCadastro_pgrdatainicial(String cadastro_pgrdatainicial) {
		this.cadastro_pgrdatainicial = cadastro_pgrdatainicial;
	}
	public String getCadastro_pgrdatafinal() {
		return cadastro_pgrdatafinal;
	}
	public void setCadastro_pgrdatafinal(String cadastro_pgrdatafinal) {
		this.cadastro_pgrdatafinal = cadastro_pgrdatafinal;
}

}

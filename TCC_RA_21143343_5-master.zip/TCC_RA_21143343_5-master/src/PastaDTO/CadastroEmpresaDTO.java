package PastaDTO;

public class CadastroEmpresaDTO {
	
	private String cadastro_cnpjempresa;
	private String cadastro_nomeempresa;
	public String getCadastro_cnpjempresa() {
		return cadastro_cnpjempresa;
	}
	public void setCadastro_cnpjempresa(String cadastro_cnpjempresa) {
		this.cadastro_cnpjempresa = cadastro_cnpjempresa;
	}
	public String getCadastro_nomeempresa() {
		return cadastro_nomeempresa;
	}
	public void setCadastro_nomeempresa(String cadastro_nomeempresa) {
		this.cadastro_nomeempresa = cadastro_nomeempresa;
	}
	

}

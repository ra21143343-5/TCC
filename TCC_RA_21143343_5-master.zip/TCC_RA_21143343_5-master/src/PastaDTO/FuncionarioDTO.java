package PastaDTO;

public class FuncionarioDTO {
	
	private String funcionarioempresa;
	private String funcionarionome;
	private String funcionariocargo;
	private int idfuncionario;
	public String getFuncionarioempresa() {
		return funcionarioempresa;
	}
	public void setFuncionarioempresa(String funcionarioempresa) {
		this.funcionarioempresa = funcionarioempresa;
	}
	public String getFuncionarionome() {
		return funcionarionome;
	}
	public void setFuncionarionome(String funcionarionome) {
		this.funcionarionome = funcionarionome;
	}
	public String getFuncionariocargo() {
		return funcionariocargo;
	}
	public void setFuncionariocargo(String funcionariocargo) {
		this.funcionariocargo = funcionariocargo;
	}
	public int getIdfuncionario() {
		return idfuncionario;
	}
	public void setIdfuncionario(int idfuncionario) {
		this.idfuncionario = idfuncionario;
	}	

}

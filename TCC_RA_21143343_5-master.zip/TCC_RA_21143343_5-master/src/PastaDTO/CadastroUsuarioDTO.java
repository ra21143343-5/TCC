package PastaDTO;

public class CadastroUsuarioDTO {
	private String cadastro_nomeusuario;
	private String cadastro_nomesenha;
	public String getCadastro_nomeusuario() {
		return cadastro_nomeusuario;
	}
	public void setCadastro_nomeusuario(String cadastro_nomeusuario) {
		this.cadastro_nomeusuario = cadastro_nomeusuario;
	}
	public String getCadastro_nomesenha() {
		return cadastro_nomesenha;
	}
	public void setCadastro_nomesenha(String cadastro_nomesenha) {
		this.cadastro_nomesenha = cadastro_nomesenha;
	}


	
}

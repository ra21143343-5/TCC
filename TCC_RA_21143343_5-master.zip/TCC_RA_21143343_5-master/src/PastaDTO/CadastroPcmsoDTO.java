package PastaDTO;

public class CadastroPcmsoDTO {
	
	private String cadastro_pcmsoempresa;
	private String cadastro_pcmsodatainicial;
	private String cadastro_pcmsodatafinal;
	public String getCadastro_pcmsoempresa() {
		return cadastro_pcmsoempresa;
	}
	public void setCadastro_pcmsoempresa(String cadastro_pcmsoempresa) {
		this.cadastro_pcmsoempresa = cadastro_pcmsoempresa;
	}
	public String getCadastro_pcmsodatainicial() {
		return cadastro_pcmsodatainicial;
	}
	public void setCadastro_pcmsodatainicial(String cadastro_pcmsodatainicial) {
		this.cadastro_pcmsodatainicial = cadastro_pcmsodatainicial;
	}
	public String getCadastro_pcmsodatafinal() {
		return cadastro_pcmsodatafinal;
	}
	public void setCadastro_pcmsodatafinal(String cadastro_pcmsodatafinal) {
		this.cadastro_pcmsodatafinal = cadastro_pcmsodatafinal;
}
	

}

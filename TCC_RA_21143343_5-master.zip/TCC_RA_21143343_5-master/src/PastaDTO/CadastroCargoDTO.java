package PastaDTO;

public class CadastroCargoDTO {
	
	private String cadastro_nomecargo;
	private String cadastro_descricaocargo;
	private String Cadastro_IdCargo;
	public String getCadastro_nomecargo() {
		return cadastro_nomecargo;
	}
	public void setCadastro_nomecargo(String cadastro_nomecargo) {
		this.cadastro_nomecargo = cadastro_nomecargo;
	}
	public String getCadastro_decricaocargo() {
		return cadastro_descricaocargo;
	}
	public void setCadastro_descricaocargo(String cadastro_descricaocargo) {
		this.cadastro_descricaocargo = cadastro_descricaocargo;
	}
	public String getCadastro_IdCargo() {
		return Cadastro_IdCargo;
	}
	public void setCadastro_IdCargo(String cadastro_IdCargo) {
		Cadastro_IdCargo = cadastro_IdCargo;
	}

}
